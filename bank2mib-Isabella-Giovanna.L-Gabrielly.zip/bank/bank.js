class Especial extends Conta{
  constructor(numero, cpf, saldo,ativo, limite){
      super(numero,cpf,saldo,ativo);
      this.limite = limite
  }
  usarLimite(valor){
     console.log("usando limite")
     if(this.ativo){
      if(valor < 0){
          console.log("Impossível realizar, valor negativo")
      } 
      else if(valor==0){
          console.log("Impossível realizar, valor zerado")
      }
      else if (valor > this.saldo + this.limite) {
          console.log("Impossível realizar, saldo e limite indisponíveis");
        } 
        else if(valor >(this.saldo + this.limite)){
          console.log("Impossível realizar, sem valor no limite e saldo...")
      }
        else {
          if (valor > this.saldo) {
            const saldoRemanente = valor - this.saldo;
            this.saldo = 0;
            this.limite -= saldoRemanente;
          } else {
            this.saldo -= valor;
          }
        }
      } else {
        console.log("Conta inativa...");

     }
  }
}


const ep = new Especial(numero, cpf, saldo, ativo, limite)

for (let x = 1; x <= 10; x++) {
  console.log("CONTA ESPECIAL");
  console.log("Saldo Atual: R$ " + ep.saldo)
  const op = leia("MOVIMENTO - D - débito ou C - crédito: ")
  const valor = parseFloat(leia("Valor do movimento: R$ "))

  if (op == "D"|| op=="d") {
    ep.debito(valor)
  } else if (op == "C"|| op=="c") {
    ep.credito(valor)
  }
}console.log("Limite atual da conta: R$" +ep.limite)
console.log("Saldo final da conta: R$" +ep.saldo)